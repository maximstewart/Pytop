"""
Mixins module 
"""
